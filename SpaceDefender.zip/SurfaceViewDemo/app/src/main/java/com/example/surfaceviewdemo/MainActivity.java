package com.example.surfaceviewdemo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements SensorEventListener {
    //Code from this program has been used from Beginning Android Games
    //Review SurfaceView, Canvas, continue

    GameSurface gameSurface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        gameSurface = new GameSurface(this);
        setContentView(gameSurface);

        SensorManager sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        Sensor rotation = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        sensorManager.registerListener(this, rotation, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause(){
        super.onPause();
        gameSurface.pause();
    }

    @Override
    protected void onResume(){
        super.onResume();
        gameSurface.resume();
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        int xSpeed = (int) ((sensorEvent.values[2]) * 20);

        Log.d("speed", String.valueOf(xSpeed));
        gameSurface.setSpeed(xSpeed);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    public class GameSurface extends SurfaceView implements Runnable {
        //https://developer.android.com/reference/android/view/SurfaceView

        Thread gameThread;
        SurfaceHolder holder;

        volatile boolean running = false;

        Bitmap background;
        Bitmap backgroundScaled;

        Bitmap player;
        Bitmap playerScaled;

        Bitmap projectile;
        Bitmap projectile2;

        Paint paintProperty;

        int screenWidth;
        int screenHeight;

        int x = 470;
        int y = 1000;

        int projectileX = 60;
        int projectileX2 = 50;
        int projectileX3 = 700;

        int projectileY = -100;
        int projectileY2 = -100-500;
        int projectileY3 = -100-1000;

        int backY = 0;

        int xSpeed = 0;
        int ySpeed = 0;

        int rotation = 0;

        public GameSurface(Context context) {
            super(context);
            holder = getHolder();

            // DEFINE OBJECT BITMAPS
            player = BitmapFactory.decodeResource(getResources(),R.drawable.player);
            background = BitmapFactory.decodeResource(getResources(), R.drawable.background);
            projectile = BitmapFactory.decodeResource(getResources(), R.drawable.projectile);
            projectile2 = BitmapFactory.decodeResource(getResources(), R.drawable.projectile2);

            // SCALE UP BITMAPS
            backgroundScaled = Bitmap.createScaledBitmap(background, 1080, 2000, false);
            playerScaled = Bitmap.createScaledBitmap(player, 160, 120, false);

            Display screenDisplay = getWindowManager().getDefaultDisplay();
            Point sizeOfScreen = new Point();
            screenDisplay.getSize(sizeOfScreen);

            screenWidth = sizeOfScreen.x;
            screenHeight = sizeOfScreen.y;

            paintProperty = new Paint();
        }

        @Override
        public void run() {
            while (running == true){
                if (holder.getSurface().isValid() == false)
                    continue;
                // https://developer.android.com/reference/android/graphics/Canvas
                Canvas canvas = holder.lockCanvas();
                canvas.drawRGB(50,50,50);

                // DRAW BACKGROUND
                for(int i = 0; i < 20; i++) {
                    canvas.drawBitmap(backgroundScaled, 0, (backY - (i*2000)), null);
                }

                // DRAW OBJECTS
                canvas.drawBitmap(playerScaled, x, y,null);

                canvas.drawBitmap(projectile, 60, projectileY, null);
                canvas.drawBitmap(projectile2, 500, projectileY2, null);
                canvas.drawBitmap(projectile2, 700, projectileY3, null);

                // OBJECT SPEEDS
                backY += 3;
                projectileY += 7;
                projectileY2 += 7;
                projectileY3 += 7;
                x += xSpeed;

                // PROJECTILE RESPAWN
                if(projectileY > 1600) {
                    projectileY = -300;
                }

                if(projectileY2 > 1600) {
                    projectileY2 = -100-500;
                }

                if(projectileY3 > 1600) {
                    projectileY3 = -100-1000;
                }

                // PLAYER BOUNDARIES
                if(x < 0) {
                    x = 0;
                }

                if(x > 930) {
                    x = 930;
                }

                holder.unlockCanvasAndPost(canvas);
            }
        }

        public void resume(){
            running = true;
            gameThread = new Thread(this);
            gameThread.start();
        }

        public void pause() {
            running = false;
            while (true) {
                try {
                    gameThread.join();
                } catch (InterruptedException e) {
                }
            }
        }

        public void setSpeed(int speed) {
            this.xSpeed = speed;
        }

    }//GameSurface
}//Activity